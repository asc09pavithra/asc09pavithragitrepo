// export class Guests {
//     id: string = "";
//     name: string = ""; 
//     email: string = "";
//     phone: string = "";
//     nationality: string = "";
//   hotel: any;
//   }
export class Guests {
  id: string="";
  name: string="";
  email: string="";
  phone: string="";
  nationality: string="";
 
}
